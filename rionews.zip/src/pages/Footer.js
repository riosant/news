const Footer = () => {
    return <>
        <div className="footer">
            <p>&copy; RioNews, All Right Reserved</p>
        </div>
    </>
}

export default Footer
